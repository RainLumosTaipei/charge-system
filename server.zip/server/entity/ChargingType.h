//
// Created by zhou_zhengming on 2025/6/7.
//

#ifndef CHARGE_SYSTEM_CHARGINGTYPE_H
#define CHARGE_SYSTEM_CHARGINGTYPE_H


enum ChargingType {
    SLOW = 0,
    FAST = 1
};


#endif //CHARGE_SYSTEM_CHARGINGTYPE_H
